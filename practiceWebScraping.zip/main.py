#!/usr/bin/python
import requests
import sys
from lxml import html
from collections import Counter

def exercise1(body):
	tree = html.fromstring(body)
	extracteditems = tree.xpath('//a[@class="mt_a"]/text()')
	print("\n".join(extracteditems))

def exercise2(body):
  tree = html.fromstring(body)
  extracteditems = tree.xpath('//td[@align="left"]//a/text()')
  counts = Counter(extracteditems)
  print(counts, sep = "\n")
  print(counts[1])

  
def exercise3(body):
	tree = html.fromstring(body)
	elements = tree.xpath('//img')
	extracteditems = list(map(lambda x: x.attrib.get('src'), elements))
	print("\n".join(extracteditems))	

def exercise4(body):
	tree = html.fromstring(body)

	sections = tree.xpath('//tr[@class="total_row_world row_continent"]')
	extracteditems = list(map(lambda x: '\"' + str(extractElements(x)) + '\"', sections))
	print("\n".join(extracteditems))

def extractElements(element):
	for item in element.findall('.//td'):
		print('  EXTRACTED: ' + str(item.text))

	return list(map(lambda x: x.text, element.findall('.//td')))

def main(url):
	try:
		response = requests.get(url)
	except:
		print ('Sorry bad url') 
		sys.exit(2)

	if response.status_code != 200:
		print ('Sorry invalid response ' + str(response.status_code))
		sys.exit(2)

	while True:
		print("")
		print("Enter 1 to 4: for respective exercise")
		print(" 1: Countries involved")
		print(" 2: Total count of each countires")
		print(" 3: Images in the wepage")
		print(" 4: Count for each continents")
		print("Enter any other key to exit"),
		choice = input("Your choice of input?: ") 

		if choice is "1":
			exercise1(response.text)
		elif choice is "2":
			exercise2(response.text)
		elif choice is "3":
			exercise3(response.text)
		elif choice is "4":
			exercise4(response.text)
		else:
			print("Input " + choice + " received. Thanks, bye bye.")
			print("")
			sys.exit(2)

if __name__ == "__main__":
	main("https://github.com/hxu296/leetcode-company-wise-problems-2022#amazon")